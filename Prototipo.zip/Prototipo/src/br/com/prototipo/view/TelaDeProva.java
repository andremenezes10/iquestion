package br.com.prototipo.view;

public class TelaDeProva {

}
