package br.com.prototipo.controller;

public class MateriaController {

}
