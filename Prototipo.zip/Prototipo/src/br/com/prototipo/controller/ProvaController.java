package br.com.prototipo.controller;

import br.com.prototipo.domain.Aluno;

public class ProvaController {

	
	//get Materia por disciplina
	//get Disciplina 
	//
	
	// Back end; 

	// Gerar prova;
	
	// Recuperar prova; - OK;
	
	// Cadastros;
	
	// recuperar cadastros; - OK;
	
	// Login - OK
	
	// Front end
	
	// Tudo
}
